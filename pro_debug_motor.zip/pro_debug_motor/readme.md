# debug Motor with dynamic reconfigure

## Build

compile the code
```
cd caktin_work
$ catkin_make
```
source the code
```
$ source devel/setup.bash 
```
## How to Use it

1.  Start node
```
$ roslaunch debug_motor c++_debug_motor.launch
```


